#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
};

int main() {
    Node* n1 = new Node();
    Node* n2 = new Node();
    Node* n3 = new Node();

    n1->data = 10;
    n2->data = 20;
    n3->data = 30;

    n1->next = n2;
    n2->next = n3;
    n3->next = NULL;

    Node* head = n1;

    cout << "Original List: ";
    Node* c1 = head;
    while (c1 != NULL) {
        cout << c1->data << " ";
        c1 = c1->next;
    }
    cout << endl;

    int pos, newValue;
    cout << "Enter position to update: ";
    cin >> pos;
    cout << "Enter new value to update: ";
    cin >> newValue;

    c1 = head;
    for (int i = 1; i < pos; i++) {
        c1 = c1->next;
    }

    c1->data = newValue;

    cout << "After Updating Position " << pos << ": ";
    c1 = head;
    while (c1 != NULL) {
        cout << c1->data << " ";
        c1 = c1->next;
    }
}

