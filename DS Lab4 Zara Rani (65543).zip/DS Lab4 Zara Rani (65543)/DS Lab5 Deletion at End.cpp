#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
};

int main() {
    Node* n1 = new Node();
    Node* n2 = new Node();
    Node* n3 = new Node();

    n1->data = 10;
    n2->data = 20;
    n3->data = 30;

    n1->next = n2;
    n2->next = n3;
    n3->next = NULL;

    Node* head = n1;

    cout << "Original List: ";
    Node* c1 = head;
    while (c1 != NULL) {
        cout << c1->data << " ";
        c1 = c1->next;
    }
    cout << endl;

    Node* prev = NULL;
    c1 = head;
    while (c1->next != NULL) {
        prev = c1;
        c1 = c1->next;
    }
    prev->next = NULL;
    delete c1;

    cout << "After Deletion at End: ";
    c1 = head;
    while (c1 != NULL) {
        cout << c1->data << " ";
        c1 = c1->next;
    }
}

