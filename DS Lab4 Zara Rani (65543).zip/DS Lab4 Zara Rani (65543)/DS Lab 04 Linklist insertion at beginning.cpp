#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
};

int main() {
  
    Node* n1 = new Node();
    Node* n2 = new Node();
    Node* n3 = new Node();
    Node* n4 = new Node();

    n1->data = 10;
    n2->data = 20;
    n3->data = 30;
    n4->data = 40;
    
    n1->next = n2;
    n2->next = n3;
    n3->next = n4;
    n4->next = NULL;
    Node* head;
    head=n1; 
	
	cout<< "Insertion at beginning "<<endl;
	Node *nn1 = new Node();
	nn1->data  = 5;
	nn1->next = head;
	head = nn1;
	Node *c1 = head;        
 
    while (c1 != NULL) {
        cout << c1->data << " ";
        c1 = c1->next;
    }

    return 0;
}
