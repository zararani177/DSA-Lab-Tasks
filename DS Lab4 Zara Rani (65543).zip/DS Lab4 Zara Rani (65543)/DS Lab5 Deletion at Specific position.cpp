#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
};

int main() {
    Node* n1 = new Node();
    Node* n2 = new Node();
    Node* n3 = new Node();

    n1->data = 10;
    n2->data = 20;
    n3->data = 30;

    n1->next = n2;
    n2->next = n3;
    n3->next = NULL;

    Node* head = n1;

    cout << "Original List: ";
    Node* c1 = head;
    while (c1 != NULL) {
        cout << c1->data << " ";
        c1 = c1->next;
    }
    cout << endl
    int pos;
    cout << "Enter position to delete: ";
    cin >> pos;

    if (pos == 1) {
        Node* toDelete = head;
        head = head->next;
        delete toDelete;
    } else {
        c1 = head;
        for (int i = 1; i < pos - 1; i++) {
            c1 = c1->next;
        }
        Node* toDelete = c1->next;
        c1->next = c1->next->next;
        delete toDelete;
    }
    cout << "After Deletion: ";
    c1 = head;
    while (c1 != NULL) {
        cout << c1->data << " ";
        c1 = c1->next;
    }
}

