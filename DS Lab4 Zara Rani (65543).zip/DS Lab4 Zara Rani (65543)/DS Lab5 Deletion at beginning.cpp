#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
};

int main() {
    Node* n1 = new Node();
    Node* n2 = new Node();
    Node* n3 = new Node();

    n1->data = 10;
    n2->data = 20;
    n3->data = 30;

    n1->next = n2;
    n2->next = n3;
    n3->next = NULL;

    Node* head;
    head = n1;

    cout << "Original List: ";
    Node* c1 = head;
    while (c1 != NULL) {
        cout << c1->data << " ";
        c1 = c1->next;
    }
    cout << endl;

    Node* temp = head;
    head = head->next; 
    delete temp;

    cout << "After Deletion at Beginning: ";
    c1 = head;
    while (c1 != NULL) {
        cout << c1->data << " ";
        c1 = c1->next;
    }
}

