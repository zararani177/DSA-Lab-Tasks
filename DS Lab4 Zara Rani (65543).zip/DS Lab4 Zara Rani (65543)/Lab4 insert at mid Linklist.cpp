#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
};

int main() {
    Node* n1 = new Node();
    Node* n2 = new Node();
    Node* n3 = new Node();
    Node* n4 = new Node();

    n1->data = 10;
    n2->data = 20;
    n3->data = 30;
    n4->data = 40;

    n1->next = n2;
    n2->next = n3;
    n3->next = n4;
    n4->next = NULL;

    Node* head;
    head = n1;
    cout<<"Insertion at mid"<<endl;
    Node* nayaNode = new Node();
    nayaNode->data = 99;
    nayaNode->next = NULL;

    int position = 3;   
    Node* temp = head;
    for (int i = 1; i < position - 1; i++) {
        if (temp != NULL) {
            temp = temp->next;
        }
    }

    nayaNode->next = temp->next;
    temp->next = nayaNode;

    Node* curr = head;
    while (curr != NULL) {
        cout << curr->data << " ";
        curr = curr->next;
    }

    return 0;
}

