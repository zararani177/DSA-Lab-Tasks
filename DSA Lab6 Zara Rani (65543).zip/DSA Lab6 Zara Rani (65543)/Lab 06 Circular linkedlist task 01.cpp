#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
};

Node* head = NULL;

Node* createNode(int value) {
    Node* newNode = new Node();
    newNode->data = value;
    newNode->next = NULL;
    return newNode;
}

void addAtBeginning(int value) {
    Node* newNode = createNode(value);

    if (head == NULL) {
        head = newNode;
        head->next = head; 
        return;
    }

    Node* temp = head;
    while (temp->next != head) 
        temp = temp->next;

    newNode->next = head;
    temp->next = newNode;
    head = newNode;
}

void addAfterValue(int target, int value) {
    if (head == NULL) {
        cout << "List is empty!" << endl;
        return;
    }

    Node* temp = head;
    do {
        if (temp->data == target) {
            Node* newNode = createNode(value);
            newNode->next = temp->next;
            temp->next = newNode;
            return;
        }
        temp = temp->next;
    } while (temp != head);

    cout << "Value " << target << " not found in list!" << endl;
}

void deleteAtBeginning() {
    if (head == NULL) {
        cout << "List is empty!" << endl;
        return;
    }

    if (head->next == head) { 
        delete head;
        head = NULL;
        return;
    }

    Node* temp = head;
    Node* tail = head;

    while (tail->next != head)
        tail = tail->next;

    head = head->next;
    tail->next = head;

    delete temp;
}

void deleteAfterValue(int target) {
    if (head == NULL) {
        cout << "List is empty!" << endl;
        return;
    }

    Node* temp = head;
    do {
        if (temp->data == target) {
            Node* nodeToDelete = temp->next;

            if (nodeToDelete == head) { 
                cout << "Cannot delete after " << target << " (it's the last node before head)" << endl;
                return;
            }

            temp->next = nodeToDelete->next;
            delete nodeToDelete;
            return;
        }
        temp = temp->next;
    } while (temp != head);

    cout << "Value " << target << " not found in list!" << endl;
}

void display() {
    if (head == NULL) {
        cout << "List is empty!" << endl;
        return;
    }

    Node* temp = head;
    cout << "List: ";
    do {
        cout << temp->data << " ";
        temp = temp->next;
    } while (temp != head);
    cout << endl;
}

int main() {
    addAtBeginning(12);
    addAtBeginning(60);
    addAtBeginning(45);
    addAtBeginning(1);

    cout << "Initial Circular Linked List: " << endl;
    display();

    int val;
    cout << "Enter value to insert at beginning: ";
    cin >> val;
    addAtBeginning(val);
    display();

    cout << "Enter value to insert after 45: ";
    cin >> val;
    addAfterValue(45, val);
    display();

    cout << "Deletion at beginning:" << endl;
    deleteAtBeginning();
    display();

    cout << "Deleting node after 45:" << endl;
    deleteAfterValue(45);
    display();

    return 0;
}

