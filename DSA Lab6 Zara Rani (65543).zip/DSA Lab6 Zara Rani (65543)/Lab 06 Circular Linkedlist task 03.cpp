#include <iostream>
#include <string>
#include <vector>
using namespace std;

struct Player {
    string name;
    int score;
    Player* next;
};

Player* head = NULL;

Player* createPlayer(string name, int score) {
    Player* newPlayer = new Player();
    newPlayer->name = name;
    newPlayer->score = score;
    newPlayer->next = NULL;
    return newPlayer;
}

void addPlayer(string name, int score) {
    Player* newPlayer = createPlayer(name, score);

    if (head == NULL) {
        head = newPlayer;
        newPlayer->next = head;
        return;
    }

    if (score < head->score) {
        Player* last = head;
        while (last->next != head) last = last->next;
        last->next = newPlayer;
        newPlayer->next = head;
        head = newPlayer;
        return;
    }

    Player* prev = head;
    Player* cur = head->next;
    while (cur != head && cur->score <= score) {
        prev = cur;
        cur = cur->next;
    }
    prev->next = newPlayer;
    newPlayer->next = cur;
}

void deletePlayer(string name) {
    if (head == NULL) {
        cout << "No players in the list!" << endl;
        return;
    }

    if (head->name == name) {
        if (head->next == head) { // only one node
            delete head;
            head = NULL;
            cout << "Player " << name << " deleted" << endl;
            return;
        }
        Player* last = head;
        while (last->next != head) last = last->next;
        Player* delNode = head;
        last->next = head->next;
        head = head->next;
        delete delNode;
        cout << "Player " << name << " deleted" << endl;
        return;
    }

    Player* prev = head;
    Player* cur = head->next;
    while (cur != head && cur->name != name) {
        prev = cur;
        cur = cur->next;
    }
    if (cur == head) {
        cout << "Player not found!" << endl;
        return;
    }
    prev->next = cur->next;
    delete cur;
    cout << "Player " << name << " deleted" << endl;
}

void displayAll() {
    if (head == NULL) {
        cout << "No players available" << endl;
        return;
    }
    Player* temp = head;
    cout << "Players List:" << endl;
    do {
        cout << temp->name << " - " << temp->score << endl;
        temp = temp->next;
    } while (temp != head);
}

void displayDescending() {
    if (head == NULL) {
        cout << "No players available!" << endl;
        return;
    }
    vector<string> names;
    vector<int> scores;
    Player* temp = head;
    do {
        names.push_back(temp->name);
        scores.push_back(temp->score);
        temp = temp->next;
    } while (temp != head);

    cout << "Players in Descending Order:" << endl;
    for (int i = (int)names.size() - 1; i >= 0; --i) {
        cout << names[i] << " - " << scores[i] << endl;
    }
}

void displayLowestScore() {
    if (head == NULL) {
        cout << "No players available!" << endl;
        return;
    }
    cout << "Lowest Score: " << head->name << " - " << head->score << endl;
}

void displaySameScore(int score) {
    if (head == NULL) {
        cout << "No players available!" << endl;
        return;
    }
    bool found = false;
    Player* temp = head;
    cout << "Players with score " << score << ":" << endl;
    do {
        if (temp->score == score) {
            cout << temp->name << " - " << temp->score << endl;
            found = true;
        }
        temp = temp->next;
    } while (temp != head);
    if (!found) cout << "No players found with score " << score << endl;
}

void displayBackwardFrom(string name) {
    if (head == NULL) {
        cout << "No players available!" << endl;
        return;
    }

    vector<string> names;
    vector<int> scores;
    Player* temp = head;
    do {
        names.push_back(temp->name);
        scores.push_back(temp->score);
        temp = temp->next;
    } while (temp != head);

    int n = (int)names.size();
    int idx = -1;
    for (int i = 0; i < n; ++i) {
        if (names[i] == name) { idx = i; break; }
    }

    if (idx == -1) {
        cout << "Player not found!" << endl;
        return;
    }

    cout << "Backward from " << name << ":" << endl;
    
    for (int k = 0; k < n; ++k) {
        int j = (idx - k) % n;
        if (j < 0) j += n;
        cout << names[j] << " - " << scores[j] << endl;
    }
}

int main() {
    int choice;
    string name;
    int score;

    do {
        cout << "\n--- Golf Tournament Menu ---\n";
        cout << "1. Add Player\n";
        cout << "2. Delete Player\n";
        cout << "3. Display All Players\n";
        cout << "4. Display Descending Order\n";
        cout << "5. Display Lowest Score\n";
        cout << "6. Display Players with Same Score\n";
        cout << "7. Display Backward from Player\n";
        cout << "8. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter Player Name: ";
                cin >> name;
                cout << "Enter Score: ";
                cin >> score;
                addPlayer(name, score);
                break;

            case 2:
                cout << "Enter Player Name to delete: ";
                cin >> name;
                deletePlayer(name);
                break;

            case 3:
                displayAll();
                break;

            case 4:
                displayDescending();
                break;

            case 5:
                displayLowestScore();
                break;

            case 6:
                cout << "Enter score to search: ";
                cin >> score;
                displaySameScore(score);
                break;

            case 7:
                cout << "Enter Player Name: ";
                cin >> name;
                displayBackwardFrom(name);
                break;

            case 8:
                cout << "Exiting..." << endl;
                break;

            default:
                cout << "Invalid choice!" << endl;
        }

    } while (choice != 8);

    return 0;
}

