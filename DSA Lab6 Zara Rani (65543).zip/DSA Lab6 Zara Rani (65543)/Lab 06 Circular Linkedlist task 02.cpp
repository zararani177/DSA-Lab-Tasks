#include <iostream>
using namespace std;

struct Node {
    int rainfall;
    Node* next;
};

Node* head = NULL;

Node* createNode(int value) {
    Node* newNode = new Node();
    newNode->rainfall = value;
    newNode->next = NULL;
    return newNode;
}

void insertAtEnd(int value) {
    Node* newNode = createNode(value);
    if (head == NULL) {
        head = newNode;
        newNode->next = head; 
    } else {
        Node* temp = head;
        while (temp->next != head) { 
            temp = temp->next;
        }
        temp->next = newNode;
        newNode->next = head; 
    }
}

int totalRainfall() {
    if (head == NULL) return 0;
    int total = 0;
    Node* temp = head;
    do {
        total += temp->rainfall;
        temp = temp->next;
    } while (temp != head);
    return total;
}

double averageRainfall() {
    if (head == NULL) return 0;
    int total = 0, count = 0;
    Node* temp = head;
    do {
        total += temp->rainfall;
        count++;
        temp = temp->next;
    } while (temp != head);
    return (double)total / count;
}

void findHighLow() {
    if (head == NULL) {
        cout << "No data available\n";
        return;
    }

    int maxRain = head->rainfall, minRain = head->rainfall;
    int maxDay = 1, minDay = 1, day = 1;

    Node* temp = head->next;
    day++;

    while (temp != head) {
        if (temp->rainfall > maxRain) {
            maxRain = temp->rainfall;
            maxDay = day;
        }
        if (temp->rainfall < minRain) {
            minRain = temp->rainfall;
            minDay = day;
        }
        temp = temp->next;
        day++;
    }

    cout << "Day with highest rainfall: Day " << maxDay << " (" << maxRain << " mm)\n";
    cout << "Day with lowest rainfall: Day " << minDay << " (" << minRain << " mm)\n";
}

void rainfallAfter5th() {
    if (head == NULL) {
        cout << "No data available\n";
        return;
    }
    Node* temp = head;
    int count = 1;

    while (count < 6) {
        temp = temp->next;
        count++;
    }

    cout << "Rainfall of the day after 5th node: " << temp->rainfall << " mm\n";
}

void displayList() {
    if (head == NULL) {
        cout << "No data to display\n";
        return;
    }
    Node* temp = head;
    int day = 1;
    cout << "Weekly Rainfall Data:\n";
    do {
        cout << "Day " << day << ": " << temp->rainfall << " mm\n";
        temp = temp->next;
        day++;
    } while (temp != head);
}

int main() {
    cout << "Enter rainfall for 7 days (non-negative values only):\n";
    for (int i = 1; i <= 7; i++) {
        int value;
        do {
            cout << "Day " << i << ": ";
            cin >> value;
            if (value < 0)
                cout << "Invalid! Rainfall cannot be negative. Try again\n";
        } while (value < 0);
        insertAtEnd(value);
    }

    cout << endl;
    displayList();

    int total = totalRainfall();
    double avg = averageRainfall();

    cout << "Total rainfall for the week: " << total << " mm\n";
    cout << "Average weekly rainfall: " << avg << " mm\n";

    findHighLow();
    rainfallAfter5th();

    return 0;
}

