#include <iostream>
using namespace std;

int main() {
    int size;
    cout << "Enter initial size of array: ";
    cin >> size;

    int *arr = new int[size];  
    int n = size;              

    cout << "Enter " << n << " elements:\n";
    for (int i = 0; i < n; i++) {
        cin >> arr[i];
    }

    int choice;
    do {
        cout << "\n---- MENU ----\n";
        cout << "1. Add element at end\n";
        cout << "2. Display elements\n";
        cout << "3. Update element\n";
        cout << "4. Delete element\n";
        cout << "5. Insert element at position\n";
        cout << "6. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        if (choice == 1) {
            int value;
            cout << "Enter value to add: ";
            cin >> value;

            int *newArr = new int[n + 1];
            for (int i = 0; i < n; i++) {
                newArr[i] = arr[i];
            }
            newArr[n] = value;
            delete[] arr;
            arr = newArr;
            n++;

            cout << "Element added!\n";

        } else if (choice == 2) {
            cout << "Array elements are: ";
            for (int i = 0; i < n; i++) {
                cout << arr[i] << " ";
            }
            cout << endl;

        } else if (choice == 3) {
            int position, value;
            cout << "Enter index to update: ";
            cin >> position;
            if (position >= 0 && position < n) {
                cout << "Enter new value: ";
                cin >> value;
                arr[position] = value;
                cout << "Element updated!\n";
            } else {
                cout << "Invalid index!\n";
            }

        } else if (choice == 4) {
            int position;
            cout << "Enter index to delete: ";
            cin >> position;
            if (position >= 0 && position < n) {
                int *newArr = new int[n - 1];
                for (int i = 0, j = 0; i < n; i++) {
                    if (i != position) {
                        newArr[j++] = arr[i];
                    }
                }
                delete[] arr;
                arr = newArr;
                n--;
                cout << "Element deleted!\n";
            } else {
                cout << "Invalid index!\n";
            }

        } else if (choice == 5) {
            int position, value;
            cout << "Enter index to insert: ";
            cin >> position;
            if (position >= 0 && position <= n) {
                cout << "Enter value: ";
                cin >> value;

                int *newArr = new int[n + 1];
                for (int i = 0, j = 0; i < n + 1; i++) {
                    if (i == position) {
                        newArr[i] = value;
                    } else {
                        newArr[i] = arr[j++];
                    }
                }
                delete[] arr;
                arr = newArr;
                n++;
                cout << "Element inserted!\n";
            } else {
                cout << "Invalid index!\n";
            }
        }

    } while (choice != 6);

    delete[] arr;
    return 0;
}

