#include<iostream>
using namespace std;
int main(){

	int rows;
	int colums;
	cout<<"Enter the rows"<<endl;
	cin>>rows;
	cout<<"Enter the columns"<<endl;
	cin>>colums;
	int array[10][10];
	for(int i=0; i<rows; i++){
		for(int j=0; j<colums; j++){
		cout << "Enter element at [" << i << "][" << j << "]: ";
            cin >> array[i][j];
        }
    }

    cout << "\nThe 2D Array is:\n";
    for(int i = 0; i < rows; i++) {
        for(int j = 0; j < colums; j++) {
            cout << array[i][j] << " ";
        }
        cout << endl; 
    }

    return 0;
}
