#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* prev;
    Node* next;
};

Node* head = NULL;

Node* createNode(int value) {
    Node* newNode = new Node();
    newNode->data = value;
    newNode->prev = newNode->next = NULL;
    return newNode;
}

void addAtBeginning(int value) {
    Node* newNode = createNode(value);
    if (head == NULL) {
        head = newNode;
        return;
    }
    newNode->next = head;
    head->prev = newNode;
    head = newNode;
}

void addAfterValue(int target, int value) {
    Node* temp = head;
    while (temp != NULL && temp->data != target)
        temp = temp->next;

    if (temp == NULL) {
        cout << "Value " << target << " not found in list! "<<endl;
        return;
    }

    Node* newNode = createNode(value);
    newNode->next = temp->next;
    newNode->prev = temp;

    if (temp->next != NULL)
        temp->next->prev = newNode;

    temp->next = newNode;
}

void deleteAtBeginning() {
    if (head == NULL) {
        cout << "List is empty! "<<endl;
        return;
    }
    Node* temp = head;
    head = head->next;
    if (head != NULL) head->prev = NULL;
    delete temp;
}

void deleteAfterValue(int target) {
    Node* temp = head;
    while (temp != NULL && temp->data != target)
        temp = temp->next;

    if (temp == NULL || temp->next == NULL) {
        cout << "Cannot delete after " << target << " (not found or no next node) "<<endl;
        return;
    }

    Node* nodeToDelete = temp->next;
    temp->next = nodeToDelete->next;

    if (nodeToDelete->next != NULL)
        nodeToDelete->next->prev = temp;

    delete nodeToDelete;
}

void display() {
    Node* temp = head;
    cout << "List: ";
    while (temp != NULL) {
        cout << temp->data << " ";
        temp = temp->next;
    }
    cout << endl;
}

int main() {
    addAtBeginning(12);
    addAtBeginning(60);
    addAtBeginning(45);
    addAtBeginning(1);

    cout << "Initial Double Linked List: "<<endl;
    display();

    int val;
    cout << "Enter value to insert at beginning: ";
    cin >> val;
    addAtBeginning(val);
    display();

    cout << "Enter value to insert after 45: ";
    cin >> val;
    addAfterValue(45, val);
    display();

    cout << "Deletion at beginning: "<<endl;;
    deleteAtBeginning();
    display();

    cout << "Deleting node after 45: "<<endl;
    deleteAfterValue(45);
    display();

    return 0;
}

