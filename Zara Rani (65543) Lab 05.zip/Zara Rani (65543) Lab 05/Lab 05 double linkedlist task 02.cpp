#include <iostream>
using namespace std;

struct Node {
    int rainfall;
    Node* prev;
    Node* next;
};

Node* head = NULL;

Node* createNode(int value) {
    Node* newNode = new Node();
    newNode->rainfall = value;
    newNode->prev = NULL;
    newNode->next = NULL;
    return newNode;
}

void insertAtEnd(int value) {
    Node* newNode = createNode(value);
    if (head == NULL) {
        head = newNode;
    } else {
        Node* temp = head;
        while (temp->next != NULL) {
            temp = temp->next;
        }
        temp->next = newNode;
        newNode->prev = temp;
    }
}

int totalRainfall() {
    int total = 0;
    Node* temp = head;
    while (temp != NULL) {
        total += temp->rainfall;
        temp = temp->next;
    }
    return total;
}

double averageRainfall() {
    int total = totalRainfall();
    int count = 0;
    Node* temp = head;
    while (temp != NULL) {
        count++;
        temp = temp->next;
    }
    return (count == 0) ? 0 : (double)total / count;
}

void findHighLow() {
    if (head == NULL) {
        cout << "No data available "<<endl;
        return;
    }

    int maxRain = head->rainfall;
    int minRain = head->rainfall;
    int maxDay = 1, minDay = 1;

    Node* temp = head->next;
    int day = 2;

    while (temp != NULL) {
        if (temp->rainfall > maxRain) {
            maxRain = temp->rainfall;
            maxDay = day;
        }
        if (temp->rainfall < minRain) {
            minRain = temp->rainfall;
            minDay = day;
        }
        temp = temp->next;
        day++;
    }

    cout << "Day with highest rainfall: Day " << maxDay << " (" << maxRain << " mm)"<<endl;
    cout << "Day with lowest rainfall: Day " << minDay << " (" << minRain << " mm)"<<endl;
}

void rainfallAfter5th() {
    Node* temp = head;
    int count = 1;

    while (temp != NULL && count < 6) {
        temp = temp->next;
        count++;
    }

    if (temp != NULL) {
        cout << "Rainfall of the day after 5th node: " << temp->rainfall << " mm "<<endl;
    } else {
        cout << "There is no day after 5th node"<<endl;
    }
}

void displayList() {
    Node* temp = head;
    int day = 1;
    cout << "Weekly Rainfall Data:"<<endl;
    while (temp != NULL) {
        cout << "Day " << day << ": " << temp->rainfall << " mm "<<endl;
        temp = temp->next;
        day++;
    }
}

int main() {
    cout << "Enter rainfall for 7 days (non-negative values only):"<<endl;
    for (int i = 1; i <= 7; i++) {
        int value;
        do {
            cout << "Day " << i << ": ";
            cin >> value;
            if (value < 0) {
                cout << "Invalid! Rainfall cannot be negative. Try again"<<endl;
            }
        } while (value < 0);
        insertAtEnd(value);
    }

    cout <<endl;
    displayList();

    int total = totalRainfall();
    double avg = averageRainfall();

    cout << "Total rainfall for the week: " << total << " mm "<<endl;
    cout << "Average weekly rainfall: " << avg << " mm "<<endl;

    findHighLow();
    rainfallAfter5th();

    return 0;
}
