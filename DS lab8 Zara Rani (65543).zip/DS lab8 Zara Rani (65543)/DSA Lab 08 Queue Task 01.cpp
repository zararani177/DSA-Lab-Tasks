#include <iostream>
#include <string>
using namespace std;

struct Applicant {
    int applicant_id;
    float height, weight, eyesight;
    string testStatus;
    Applicant* next;
    Applicant* prev;
};

class ApplicantQueue {
private:
    Applicant* front;
    Applicant* rear;

public:
    ApplicantQueue() {
        front = rear = NULL;
    }

    void enqueue(int id, float height, float weight, float eyesight, string status) {
        Applicant* newNode = new Applicant{id, height, weight, eyesight, status, NULL, NULL};

        if (!rear) {
            front = rear = newNode;
        } else {
            rear->next = newNode;
            newNode->prev = rear;
            rear = newNode;
        }
        cout << "Applicant " << id << " joined the line.\n";
    }

    void dequeue() {
        if (!front) {
            cout << "No applicants in the queue.\n";
            return;
        }
        Applicant* temp = front;
        cout << "Applicant " << temp->applicant_id << " completed the test and left the line.\n";
        front = front->next;
        if (front) front->prev = NULL;
        else rear = NULL;
        delete temp;
    }

    void removeAtPosition(int position) {
        if (!front) {
            cout << "Queue is empty.\n";
            return;
        }

        Applicant* current = front;
        int index = 1;

        while (current && index < position) {
            current = current->next;
            index++;
        }

        if (!current) {
            cout << "Invalid position.\n";
            return;
        }

        cout << "Applicant " << current->applicant_id << " (at position " 
             << position << ") left the line due to urgency.\n";

        if (current->prev)
            current->prev->next = current->next;
        else
            front = current->next;  

        if (current->next)
            current->next->prev = current->prev;
        else
            rear = current->prev;   

        delete current;
    }

    void display() {
        if (!front) {
            cout << "Queue is empty.\n";
            return;
        }

        cout << "\nCurrent Queue:\n";
        Applicant* temp = front;
        int pos = 1;
        while (temp) {
            cout << pos++ << ". ID: " << temp->applicant_id;
            cout << " | Height: " << temp->height;
            cout << " | Weight: " << temp->weight;
            cout << " | Eyesight: " << temp->eyesight;
            cout << " | Status: " << temp->testStatus << endl;
            temp = temp->next;
        }
        cout << endl;
    }
};

int main() {
    ApplicantQueue q;

    q.enqueue(101, 170.2, 65.5, 6.5, "Waiting");
    q.enqueue(102, 165.4, 70.0, 6.2, "Waiting");
    q.enqueue(103, 172.0, 68.3, 6.8, "Waiting");
    q.enqueue(104, 180.1, 75.0, 6.9, "Waiting");
    q.enqueue(105, 177.5, 66.7, 6.4, "Waiting");
    q.enqueue(106, 169.3, 69.1, 6.3, "Waiting");
    q.enqueue(107, 175.0, 73.5, 6.7, "Waiting");

    q.display();
    
    q.removeAtPosition(2);

    q.display();

    q.dequeue();

    q.display();

    return 0;
}
