#include<iostream>
using namespace std;
int main ()
{
	int index;
	
	int students [5] = {6 ,5 ,3 ,9 ,2 };
	int size = 5;
    for(int i=0;i<size;i++){
	cout<<students[i]<<" "<<endl;
}
    cout<<"Enter the index to delete"<<endl;
    cin>>index;
    if (index >= 0 && index < size){
    for(int i=index; i<size; i++){
    students[i] = students[i+1];
	}
   size--;
	cout<<"Array after deletion"<<endl;
	for(int i=0; i<size; i++){
	cout<<students[i];
	}
}
else{
	cout<<"invalid index"<<endl;
}
	return 0;
}

