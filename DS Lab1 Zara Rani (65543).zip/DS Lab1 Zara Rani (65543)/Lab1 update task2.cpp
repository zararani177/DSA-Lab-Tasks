#include<iostream>
using namespace std;
int main (){
	int index;
	int value;
	int students [5] = {6 ,5 ,3 ,9 ,1 };
	int size = 5;
    for(int i=0;i<size;i++){
	cout<<students[i]<<endl;
}
    cout<<"Enter the index to update"<<endl;
    cin>>index;
    if(index >= 0 && index < size){
    cout<<"Enter the value"<<endl;
    cin>>value;
	students[index]=value;
	cout<<"Array after update"<<endl;
	for(int i=0; i<size; i++){
	cout<<students[i];
	}
}
else{
	cout<<"invalid array"<<endl;
}
	return 0;
}
