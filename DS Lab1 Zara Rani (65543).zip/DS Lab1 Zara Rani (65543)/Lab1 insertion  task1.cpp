#include<iostream>
using namespace std;
int main (){
	int index;
	int value;
	int students [5] = {6 ,5 ,3 ,9 ,1 };
	int size = 5;
    for(int i=0;i<size;i++){
	cout<<students[i]<<endl;
}
    cout<<"Enter the index"<<endl;
    cin>>index;
    cout<<"Enter the value"<<endl;
    cin>>value;
    for(int i=size; i>index; i--){
    students[i] = students[i-1];
	}
	students[index]=value;
	size++;
	cout<<"Array after insertion"<<endl;
	for(int i=0; i<size; i++){
	cout<<students[i];
	}
	return 0;
}
