#include<iostream>
using namespace std;
int main(){
	int *pointer = NULL;
	cout<<"The value of pointer is" << pointer<<endl;
	return 0;
}
