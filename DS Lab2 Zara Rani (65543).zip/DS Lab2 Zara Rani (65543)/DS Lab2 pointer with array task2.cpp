#include<iostream>
using namespace std;
int main(){
	const int size = 3;
	int array[size] = {5,10,15};
	int *ptr;
	ptr = &array[size-1];
	for (int i=0; i<size; i++){
		cout<<"Address of array[" << i << "] = ";
		cout<< ptr << endl;
		cout<< "Value or array[" << i <<"] = ";
		cout<< *ptr <<endl;
		ptr--;
	}
	return 0;
}
