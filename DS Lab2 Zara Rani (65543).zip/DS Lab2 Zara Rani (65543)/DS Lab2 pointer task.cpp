#include<iostream>
using namespace std;
int main(){
	int a,b;
	a = 88;
	b = 100;
	cout<<"The address of a is" <<&a<<endl;
	cout<<"the address of b is"  <<&b<<endl;
	return 0;
}
